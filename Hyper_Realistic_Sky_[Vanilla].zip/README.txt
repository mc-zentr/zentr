This pack will work with the vanilla game, no mods required.

Does work with Sodium too, just ignore the incompatibility warning.

Works from Minecraft version 25w10a and above.

Thanks to Csala Bálint for providing the template pack.
https://github.com/BalintCsala/minecraft-vanilla-skybox

Enjoy!

-UsernameGeri